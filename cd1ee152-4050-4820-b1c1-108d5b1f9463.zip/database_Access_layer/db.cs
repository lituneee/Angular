﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using AngularPagination.Models;
namespace AngularPagination.database_Access_layer
{
    public class db
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
        regsiterlist reglist = new regsiterlist();
        public regsiterlist Get_Paging_data(int pagesize,int pageindex)
        {
            SqlCommand com = new SqlCommand("Sp_Get_data", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@Pageindex", pageindex);
            com.Parameters.AddWithValue("@Pagesize", pagesize);
            con.Open();
            SqlDataReader dr = com.ExecuteReader();
            List<register> rslist = new List<register>();
            while (dr.Read())
            {
                register rs = new register();
                rs.Sr_no = Convert.ToInt32(dr["Sr_no"]);
                rs.Email = dr["Email"].ToString();
                rs.Password = dr["Password"].ToString();
                rs.Name = dr["Name"].ToString();
                rs.Address = dr["Address"].ToString();
                rs.City = dr["City"].ToString();
                rslist.Add(rs);
            }
            dr.NextResult();
            while (dr.Read())
            {
                reglist.totalcount = Convert.ToInt32(dr["totalcount"]);
            }
            reglist.registerdata = rslist;
            return reglist;
        }
    }
}