﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using AngularPagination.Models;
namespace AngularPagination.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        database_Access_layer.db dblayer = new database_Access_layer.db();
        public ActionResult Index()
        {
            return View();
        }

        public JsonResult get_data(int pageindex,int pagesize)
        {
            regsiterlist rslist = new regsiterlist();
            rslist = dblayer.Get_Paging_data(pagesize,pageindex);
            return Json(rslist, JsonRequestBehavior.AllowGet);
        }
    }
}
