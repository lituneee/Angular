﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AngularPagination.Models
{
    public class regsiterlist
    {
        public List<register> registerdata { get; set; }
        public int totalcount { get; set; }
    }
}